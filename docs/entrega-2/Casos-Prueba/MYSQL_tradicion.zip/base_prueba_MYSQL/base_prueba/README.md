# Versión MySQL - Entrega 2

Esta versión de la web fue adaptada para trabajar exclusivamente con la base `bd_tradicion` en MySQL 8.x.

## Requisitos
- Node.js 18 o superior
- MySQL Server 8.x
- MySQL Workbench (opcional, para administrar la BD)
- Base `bd_tradicion` creada con `bd_tradicion_mysql.sql`

## Configuración
1. Copia `.env.example` como `.env`.
2. Coloca tu usuario y contraseña reales de MySQL en `.env`.
3. Verifica:

```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=bd_tradicion
DB_USER=root
DB_PASSWORD=TU_CONTRASENA_MYSQL
```

## Instalación

```bash
npm install
npm start
```

Abre `http://localhost:3000/login`.

## Usuario de prueba existente en el SQL
- Usuario: `admin`
- Contraseña: `admin123`

## Cambios principales respecto a Oracle
- `oracledb` se reemplazó por `mysql2`.
- Puerto `1521` se reemplazó por `3306`.
- SID/servicio Oracle se reemplazó por el esquema MySQL `bd_tradicion`.
- Parámetros `:1`, `:2`, etc. se reemplazaron por `?`.
- `SEQ_CLIENTE.NEXTVAL` y `SEQ_PROVEEDOR.NEXTVAL` ya no se usan; esas tablas usan `AUTO_INCREMENT`.
- `SYSDATE` se reemplazó por `CURRENT_TIMESTAMP`.
- Las consultas usan nombres de tabla y columna en `snake_case`.

## Módulos CRUD activos
- Clientes
- Proveedores
- Login / autenticación

La interfaz visual existente se conservó.
