# 🚀 GUÍA DE INSTALACIÓN PASO A PASO
**Empresa de Tortillas, Nachos y Harina - Entrega 2**

---

## ✅ Prerequisitos

Antes de comenzar, asegúrate de tener instalado:

- **Node.js** versión 14 o superior → [Descargar](https://nodejs.org/)
- **npm** (viene con Node.js)
- **MySQL Server** o **Oracle Database** → [Descargar MySQL](https://dev.mysql.com/downloads/mysql/)
- **Cliente MySQL** (para ejecutar scripts SQL)
  - **Windows:** MySQL Workbench o línea de comandos
  - **Linux/Mac:** Cliente mysql

### Verificar Instalación

```bash
# Verificar Node.js
node --version
# Debe mostrar v14.0.0 o superior

# Verificar npm
npm --version
# Debe mostrar 6.0.0 o superior

# Verificar MySQL (si está instalado)
mysql --version
# Debe mostrar una versión válida
```

---

## 📋 PASO 1: Preparar la Base de Datos

### 1.1 Crear Base de Datos

```bash
# Conectar a MySQL como root
mysql -u root -p

# Ingresar contraseña (la que estableciste en instalación)
```

```sql
-- Una vez dentro de MySQL:

-- Crear la base de datos
CREATE DATABASE BDTradicion CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear usuario de la aplicación (opcional, pero recomendado)
CREATE USER 'tortillas'@'localhost' IDENTIFIED BY 'contraseña_segura';

-- Otorgar permisos
GRANT ALL PRIVILEGES ON BDTradicion.* TO 'tortillas'@'localhost';
FLUSH PRIVILEGES;

-- Salir
EXIT;
```

### 1.2 Crear Tabla de Usuarios

```bash
# Opción A: Usando archivo SQL (RECOMENDADO)
mysql -u root -p BDTradicion < docs/entrega-2/schema.sql

# Opción B: Manualmente
mysql -u root -p
USE BDTradicion;
# Pegar el contenido de docs/entrega-2/schema.sql
```

### 1.3 Verificar que la Tabla se Creó

```bash
mysql -u root -p BDTradicion -e "SELECT * FROM usuarios;"

# Deberías ver:
# id_usuario | nombre_usuario | email | password_hash | ... | activo
#          1 | admin          | admin@empresa.com | $2a$10$... | 1
```

---

## 📥 PASO 2: Descargar/Clonar el Proyecto

```bash
# Opción A: Si ya existe el proyecto descargado
cd "base prueba"

# Opción B: Clonar desde repositorio (si existe)
git clone <url-del-repositorio>
cd nombre-proyecto
```

---

## 📦 PASO 3: Instalar Dependencias

```bash
# Instalar todas las dependencias necesarias
npm install

# Esto descargará:
# - express (servidor web)
# - express-session (manejo de sesiones)
# - ejs (motor de plantillas)
# - dotenv (variables de entorno)
# - bcryptjs (hashing de contraseñas)
# - mysql2 (cliente MySQL)
# - nodemon (herramienta de desarrollo)

# Esperar a que termine (puede tomar 1-2 minutos)
```

**Verificar instalación:**
```bash
npm list
# Debe mostrar todas las dependencias instaladas
```

---

## ⚙️ PASO 4: Configurar Variables de Entorno

### 4.1 Crear archivo .env

```bash
# Copiar el archivo de ejemplo
cp .env.example .env

# En Windows PowerShell:
Copy-Item .env.example .env
```

### 4.2 Editar archivo .env

Abrir `.env` con tu editor de texto favorito (VS Code, Notepad++, etc.):

```env
# OPCIÓN 1: BD en localhost
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_NAME=BDTradicion
DB_USER=root
DB_PASSWORD=contraseña_de_root
SESSION_SECRET=clave_secreta_cambiar_en_produccion
```

```env
# OPCIÓN 2: BD en otro servidor de la red
PORT=3000
DB_HOST=192.168.1.100
DB_PORT=3306
DB_NAME=BDTradicion
DB_USER=tortillas
DB_PASSWORD=contraseña_segura
SESSION_SECRET=clave_secreta_cambiar_en_produccion
```

### 4.3 Valores a Usar

**Reemplazar según tu configuración:**
- `DB_HOST`: 
  - `localhost` si BD está en tu máquina
  - `192.168.x.x` si BD está en otro servidor
  - `servidor.empresa.com` si es servidor remoto
- `DB_PORT`: 
  - `3306` para MySQL
  - `1521` para Oracle
- `DB_NAME`: Nombre de la BD (en este caso: `BDTradicion`)
- `DB_USER`: Usuario de BD con permisos (ej: `root` o `tortillas`)
- `DB_PASSWORD`: Contraseña del usuario de BD
- `SESSION_SECRET`: Clave única para sesiones (puede ser cualquier string)

---

## 🧪 PASO 5: Verificar Conexión a BD

### Opción A: Test rápido en Node.js

```bash
# Crear archivo test.js temporalmente
cat > test-db.js << 'EOF'
const db = require('./web/config/database');

db.getAll('SELECT 1')
  .then(() => {
    console.log('✓ Conexión a BD exitosa');
    process.exit(0);
  })
  .catch(err => {
    console.error('✗ Error de conexión:', err.message);
    process.exit(1);
  });
EOF

# Ejecutar test
node test-db.js

# Eliminar archivo test
rm test-db.js
```

### Opción B: Test en MySQL directamente

```bash
# Verificar que la tabla existe
mysql -u root -p BDTradicion -e "DESCRIBE usuarios;"

# Debe mostrar la estructura de la tabla
```

---

## 🚀 PASO 6: Iniciar el Servidor

### 6.1 Modo Desarrollo (Con reinicio automático)

```bash
# Usar nodemon (recarga automática si hay cambios)
npm run dev

# Verás en la consola:
# ✓ Conexión a BD iniciada
# ✓ Servidor iniciado correctamente
# ✓ Puerto: 3000
```

### 6.2 Modo Producción

```bash
# Sin reinicio automático
npm start
```

### 6.3 Ver Logs

```
╔════════════════════════════════════════════════════════════╗
║  ✓ Servidor iniciado correctamente                        ║
║  ✓ Empresa de Tortillas, Nachos y Harina - Entrega 2      ║
║  ✓ Puerto: 3000                                            ║
║  ✓ Ambiente: development                                  ║
║  ✓ Base de Datos: localhost:3306                          ║
║                                                            ║
║  🌐 Acceder en: http://localhost:3000                     ║
║  📝 Login: http://localhost:3000/login                    ║
╚════════════════════════════════════════════════════════════╝
```

---

## 🌐 PASO 7: Acceder a la Aplicación

### 7.1 Abrir en el Navegador

```
http://localhost:3000
```

Serás redirigido a `/login` si no estás autenticado.

### 7.2 Hacer Login

- **Usuario:** `admin`
- **Contraseña:** `admin123`

Después del login exitoso, verás el **Dashboard** con:
- Bienvenida personalizada
- Tarjetas de estadísticas
- Módulos CRUD (en desarrollo)

### 7.3 Hacer Logout

- Click en tu nombre en la esquina superior derecha
- Luego click en "Salir"
- Serás redirigido a `/login`

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Problema: "Error de conexión a BD"

**Causa:** Variables de entorno incorrectas

```bash
# Verificar que:
1. BD está corriendo (MySQL debe estar activo)
2. .env existe y tiene valores correctos
3. Usuario/contraseña son correctos
4. Puerto es correcto (3306 para MySQL, 1521 para Oracle)

# Solución:
# 1. Revisar .env
cat .env

# 2. Verificar MySQL está corriendo
mysql -u root -p -e "SELECT 1;"

# 3. Revisar logs del servidor
# (Ver en la consola donde ejecutó npm start)
```

### Problema: "Puerto 3000 ya está en uso"

```bash
# Cambiar puerto en .env
# DE:
PORT=3000
# A:
PORT=3001

# Luego reiniciar servidor
npm run dev
```

### Problema: "npm: command not found"

```bash
# Node.js no está instalado o no está en el PATH
# Solución: Reinstalar Node.js desde https://nodejs.org/

# Verificar después:
node --version
npm --version
```

### Problema: "Tabla usuarios no existe"

```bash
# Ejecutar el script SQL nuevamente
mysql -u root -p BDTradicion < docs/entrega-2/schema.sql

# Verificar:
mysql -u root -p BDTradicion -e "SHOW TABLES;"
```

### Problema: "Login falla aunque usuario/contraseña son correctos"

```bash
# Verificar que el usuario existe en BD
mysql -u root -p BDTradicion -e "SELECT * FROM usuarios WHERE nombre_usuario='admin';"

# Si no aparece, insertar usuario de prueba nuevamente
mysql -u root -p BDTradicion -e "
INSERT INTO usuarios (nombre_usuario, email, password_hash, nombre_completo, activo)
VALUES ('admin', 'admin@empresa.com', '\$2a\$10\$N9qo8ucowan11ie3yppK2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW', 'Administrador', 1);
"
```

---

## 📊 Verificación Final

Después de completar todos los pasos:

```bash
# 1. Verificar que el servidor está corriendo
# Deberías ver en la consola:
✓ Conexión a BD iniciada
✓ Servidor iniciado correctamente

# 2. Abrir navegador y acceder a:
http://localhost:3000

# 3. Deberías ver:
✓ Página de login
✓ Formulario con campos usuario/contraseña

# 4. Hacer login con:
Usuario: admin
Contraseña: admin123

# 5. Después del login, deberías ver:
✓ Dashboard con bienvenida
✓ Tarjetas de estadísticas
✓ Módulos en desarrollo
✓ Navbar con opciones de navegación
✓ Botón de Salir
```

---

## 🎉 ¡Listo!

Si llegaste aquí sin errores, el proyecto está correctamente instalado y funcionando.

### Próximos Pasos

1. Explorar la interfaz
2. Revisar el código en `web/`
3. Leer `docs/entrega-2/AVANCE_WEB.md` para detalles técnicos
4. Leer `docs/entrega-2/bitacora-ia/BITACORA_DEV3.md` para arquitectura
5. Prepararse para integración de módulos CRUD (Desarrollador 4)

---

## 📞 Ayuda Adicional

**Archivos útiles:**
- `README.md` - Descripción general
- `docs/entrega-2/AVANCE_WEB.md` - Detalle de implementación
- `docs/entrega-2/bitacora-ia/BITACORA_DEV3.md` - Detalles técnicos
- `docs/entrega-2/schema.sql` - Script de BD

**Comandos útiles:**
```bash
npm install          # Instalar dependencias
npm start           # Iniciar en producción
npm run dev         # Iniciar en desarrollo (con nodemon)
npm list            # Ver dependencias instaladas
npm update          # Actualizar dependencias
```

---

**Versión:** 1.0.0  
**Fecha:** 31 de Agosto de 2024  
**Empresa:** Empresa de Tortillas, Nachos y Harina
