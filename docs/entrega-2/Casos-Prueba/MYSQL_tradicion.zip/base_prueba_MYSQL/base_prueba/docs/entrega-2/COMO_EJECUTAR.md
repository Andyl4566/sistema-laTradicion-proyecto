# 🚀 GUÍA DE EJECUCIÓN Y PRUEBA
**Empresa de Tortillas, Nachos y Harina | Entrega 2**  
**Cómo ejecutar y probar la aplicación paso a paso (con Oracle)**

---

## ✅ REQUISITOS PREVIOS

Antes de ejecutar, asegúrate de tener:

- ✅ **Node.js** v14+ instalado → [Descargar](https://nodejs.org/)
- ✅ **npm** (viene con Node.js)
- ✅ **Oracle Database** corriendo (o disponible en red)
- ✅ Base de datos `BDTradicion` (o tu SID Oracle) creada
- ✅ Tabla `usuarios` creada en Oracle
- ✅ Usuario Oracle con permisos para acceder a la tabla

---

## 🛠️ PASO 1: PREPARAR LA BASE DE DATOS ORACLE

### 1.1 Conectar a Oracle

```bash
# Usando SQL*Plus (desde la máquina con Oracle instalado)
sqlplus SYSTEM@BDTradicion

# O si Oracle está en otra máquina
sqlplus SYSTEM@192.168.1.50:1521/BDTradicion

# Contraseña: tu_contraseña_de_SYSTEM
```

### 1.2 Crear la Tabla de Usuarios (si no existe)

Si ya tienes la tabla, salta este paso.

```sql
-- Crear secuencia para IDs
CREATE SEQUENCE seq_usuarios START WITH 1 INCREMENT BY 1;

-- Crear tabla usuarios
CREATE TABLE usuarios (
  id_usuario NUMBER PRIMARY KEY,
  nombre_usuario VARCHAR2(50) UNIQUE NOT NULL,
  email VARCHAR2(100) UNIQUE NOT NULL,
  password_hash VARCHAR2(255) NOT NULL,
  nombre_completo VARCHAR2(100),
  activo NUMBER(1) DEFAULT 1,
  fecha_creacion DATE DEFAULT SYSDATE
);

-- Crear índices
CREATE INDEX idx_usuario_nombre ON usuarios(nombre_usuario);
CREATE INDEX idx_usuario_email ON usuarios(email);

-- Insertar usuario de prueba
-- Contraseña hasheada con bcrypt (admin/admin123)
INSERT INTO usuarios (id_usuario, nombre_usuario, email, password_hash, nombre_completo, activo)
VALUES (seq_usuarios.NEXTVAL, 'admin', 'admin@empresa.com', '$2a$10$eImiTXuWVxfaHNYY0iNAeuK2kRabMmU8q/cqD3UcK50DYVzL5qK5m', 'Administrador', 1);

COMMIT;
```

### 1.3 Verificar la Tabla

```sql
-- Verificar que la tabla existe
SELECT * FROM usuarios;

-- Deberías ver:
-- ID_USUARIO | NOMBRE_USUARIO | EMAIL | PASSWORD_HASH | ...
--          1 | admin          | admin@empresa.com | $2a$10$... | 1
```

---

## 📥 PASO 2: INSTALAR LA APLICACIÓN

```bash
# Navegar a la carpeta del proyecto
cd "base prueba"

# Instalar todas las dependencias (incluyendo oracledb)
npm install

# Esperar a que termine (2-3 minutos)
# NOTA: oracledb puede necesitar compilación, es normal si tarda más
# Verás líneas como:
# added 200 packages in 2m
```

### Nota sobre oracledb

Si tienes problemas con `npm install`, asegúrate de tener:
- Python 3.x instalado (para compilar oracledb)
- Visual Studio Build Tools (en Windows)
- Si todo falla, contacta al administrador de Oracle

---

## ⚙️ PASO 3: CONFIGURAR VARIABLES DE ENTORNO

### 3.1 Crear archivo .env

```bash
# Copiar template
cp .env.example .env
```

### 3.2 Editar archivo .env para Oracle

Abrir `.env` con tu editor (VS Code, Notepad++, etc.) y reemplazar:

```env
# Servidor web
PORT=3000

# Conexión a Oracle Database
# Cambia según tu configuración
DB_HOST=localhost
DB_PORT=1521
DB_NAME=BDTradicion
DB_USER=SYSTEM
DB_PASSWORD=tu_contraseña_oracle_aqui

# Seguridad
SESSION_SECRET=clave_super_secreta_cambiar_en_prod
```

### 3.3 Ejemplos de Configuración

**Para Oracle local:**
```env
DB_HOST=localhost
DB_PORT=1521
DB_NAME=BDTradicion
DB_USER=SYSTEM
DB_PASSWORD=admin123
```

**Para Oracle en red local:**
```env
DB_HOST=192.168.1.50
DB_PORT=1521
DB_NAME=BDTradicion
DB_USER=SYSTEM
DB_PASSWORD=tu_contraseña
```

**Para Oracle en servidor remoto:**
```env
DB_HOST=oracle.empresa.com
DB_PORT=1521
DB_NAME=BDTradicion
DB_USER=usuario_bd
DB_PASSWORD=contraseña_segura
```

---

**Importante:** 
- `DB_USER`: Usuario Oracle (normalmente `SYSTEM`)
- `DB_PASSWORD`: La contraseña que pusiste para el usuario Oracle
- `DB_HOST`: IP o nombre del servidor Oracle
- `DB_PORT`: Puerto de Oracle (por defecto 1521)
- `DB_NAME`: SID de la base de datos Oracle

---

## 🎯 PASO 4: INICIAR EL SERVIDOR

### Opción A: Modo Desarrollo (Recomendado para pruebas)

```bash
npm run dev
```

**Verás en la consola:**

```
╔════════════════════════════════════════════════════════════╗
║  ✓ Servidor iniciado correctamente                        ║
║  ✓ Empresa de Tortillas, Nachos y Harina - Entrega 2      ║
║  ✓ Puerto: 3000                                            ║
║  ✓ Ambiente: development                                  ║
║  ✓ Base de Datos Oracle: localhost:1521/BDTradicion       ║
║                                                            ║
║  🌐 Acceder en: http://localhost:3000                     ║
║  📝 Login: http://localhost:3000/login                    ║
╚════════════════════════════════════════════════════════════╝
```

### Opción B: Modo Producción

```bash
npm start
```

**Nota:** Con `npm run dev` se reinicia automáticamente si cambias código

---

## 🌐 PASO 5: ACCEDER A LA APLICACIÓN

### 5.1 Abrir en el Navegador

```
http://localhost:3000
```

**Deberías ver:**
- Página de **Login** con formulario
- Dos columnas: branding a la izquierda, formulario a la derecha
- Datos de prueba mostrados

### 5.2 Hacer Login

**Usuario:** `admin`  
**Contraseña:** `admin123`

**Después del login, verás:**
- ✅ **Dashboard** con bienvenida personalizada
- ✅ **Tarjetas** de estadísticas
- ✅ **Módulos CRUD** (4 placeholders en desarrollo)
- ✅ **Navegación** en la parte superior

---

## 🧪 PASO 6: PROBAR LAS FUNCIONALIDADES

### 6.1 Probar Login

```
✅ Página inicial: http://localhost:3000
   → Deberías ser redirigido a /login

✅ Ingresa:
   - Usuario: admin
   - Contraseña: admin123

✅ Presiona "Iniciar Sesión"
   → Deberías ir al Dashboard
```

### 6.2 Probar Dashboard

```
✅ En el Dashboard (/home), verás:
   - Encabezado con bienvenida: "¡Bienvenido, Administrador!"
   - Tu nombre en la esquina superior derecha
   - Tarjetas con estadísticas
   - 4 módulos CRUD (Productos, Órdenes, Reportes, Configuración)
   - Información del sistema
```

### 6.3 Probar Navegación

```
✅ Haz click en "Tortillas, Nachos & Harina" (logo)
   → Regresa al Dashboard

✅ Haz click en tu nombre en la esquina superior derecha
   → Verás el botón "Salir"

✅ Haz click en "Salir"
   → Sesión cerrada
   → Redirigido a /login
```

### 6.4 Probar Login Fallido

```
✅ Intenta login con datos incorrectos:
   - Usuario: usuario_falso
   - Contraseña: contraseña_falsa

✅ Verás mensaje de error amigable:
   "Nombre de usuario o contraseña incorrectos"

✅ El formulario permanece visible para reintentar
```

### 6.5 Probar Acceso sin Autenticación

```
✅ Intenta acceder directamente:
   http://localhost:3000/home

✅ Sin estar logueado:
   → Serás redirigido automáticamente a /login
```

---

## 🔍 PASO 7: REVISAR LOGS

### Logs del Servidor

En la consola donde ejecutaste `npm run dev`, verás:

```
[2024-08-31T10:00:00.000Z] GET /login
[2024-08-31T10:00:05.000Z] POST /login
✓ Login exitoso para usuario: admin
[2024-08-31T10:00:06.000Z] GET /home
[2024-08-31T10:00:10.000Z] GET /logout
✓ Logout para usuario: admin
```

**Esto significa:**
- ✅ Servidor está recibiendo requests
- ✅ Login es procesado correctamente
- ✅ Sesión se crea y destruye

---

## 🐛 PASO 8: SOLUCIONAR PROBLEMAS

### Error: "Connection refused" o "Cannot connect to database"

```bash
# Verificar que Oracle está corriendo:
# Windows: Ver en Services o usar SQL*Plus
# Linux: ps aux | grep oracle
# Mac: ps aux | grep oracle

# Verificar conectividad a Oracle:
sqlplus SYSTEM@localhost:1521/BDTradicion

# Si la conexión falla, verificar:
# 1. Oracle está corriendo
# 2. SID es correcto (BDTradicion)
# 3. Puerto es correcto (1521)
# 4. Credenciales son correctas (SYSTEM)
# 5. Si es red remota, verificar firewall

# Luego reintentar:
npm run dev
```

### Error: "Port 3000 already in use"

```bash
# Cambiar puerto en .env
PORT=3001

# Reiniciar servidor
npm run dev

# Acceder a: http://localhost:3001
```

### Error: "ORA-00942: table or view does not exist"

```bash
# La tabla 'usuarios' no existe en Oracle
# Conectar a Oracle y crear la tabla:

sqlplus SYSTEM@BDTradicion

-- Dentro de SQL*Plus:
CREATE SEQUENCE seq_usuarios START WITH 1 INCREMENT BY 1;

CREATE TABLE usuarios (
  id_usuario NUMBER PRIMARY KEY,
  nombre_usuario VARCHAR2(50) UNIQUE NOT NULL,
  email VARCHAR2(100) UNIQUE NOT NULL,
  password_hash VARCHAR2(255) NOT NULL,
  nombre_completo VARCHAR2(100),
  activo NUMBER(1) DEFAULT 1,
  fecha_creacion DATE DEFAULT SYSDATE
);

INSERT INTO usuarios VALUES (seq_usuarios.NEXTVAL, 'admin', 'admin@empresa.com', 
  '$2a$10$eImiTXuWVxfaHNYY0iNAeuK2kRabMmU8q/cqD3UcK50DYVzL5qK5m', 'Administrador', 1, SYSDATE);

COMMIT;
EXIT;

# Luego reintentar:
npm run dev
```

### Error: "ORA-01017: invalid username/password; logon denied"

```bash
# Las credenciales en .env son incorrectas
# Verificar usuario y contraseña de Oracle
# Editar .env con credenciales correctas:

DB_USER=SYSTEM
DB_PASSWORD=tu_contraseña_correcta

# Reintentar:
npm run dev
```

### Error: "Cannot find module 'oracledb'"

```bash
# oracledb no se instaló correctamente
# Intentar reinstalar:
npm install oracledb

# Si sigue fallando, puede haber problemas de compilación
# En Windows, asegúrate de tener:
# - Python 3.x
# - Visual Studio Build Tools
# - Node.js compatible

# Como alternativa, instalar versión precompilada:
npm install oracledb@latest --build-from-source=false
```

---

## ✅ CHECKLIST DE PRUEBA COMPLETA

Marca conforme pruebes cada funcionalidad:

- [ ] **Instalación**
  - [ ] `npm install` completó sin errores
  - [ ] `.env` creado y configurado
  - [ ] Tabla usuarios creada en Oracle
  - [ ] Usuario admin existe en BD

- [ ] **Servidor**
  - [ ] `npm run dev` inicia sin errores
  - [ ] Mensaje de bienvenida aparece
  - [ ] Oracle conecta correctamente ("✓ Pool de conexiones Oracle creado")

- [ ] **Página de Login**
  - [ ] Accedo a http://localhost:3000
  - [ ] Veo formulario de login
  - [ ] Formulario tiene campos: usuario y contraseña
  - [ ] Datos de prueba se muestran

- [ ] **Login Exitoso**
  - [ ] Ingreso usuario: admin, contraseña: admin123
  - [ ] Click en "Iniciar Sesión"
  - [ ] Redirigido a /home
  - [ ] Dashboard se muestra correctamente

- [ ] **Dashboard**
  - [ ] Veo bienvenida: "¡Bienvenido, Administrador!"
  - [ ] Mi nombre aparece en la esquina superior derecha
  - [ ] Veo 4 tarjetas de estadísticas
  - [ ] Veo 4 módulos CRUD (en desarrollo)
  - [ ] Información del sistema se muestra
  - [ ] Navbar superior funciona

- [ ] **Navegación**
  - [ ] Click en logo regresa al dashboard
  - [ ] Click en "Dashboard" en navbar funciona
  - [ ] Puedo ver "Salir" cuando hago click en mi nombre
  - [ ] Otros enlaces están disponibles

- [ ] **Logout**
  - [ ] Click en "Salir"
  - [ ] Sesión se cierra
  - [ ] Redirigido a /login
  - [ ] Mensaje "Sesión cerrada correctamente"

- [ ] **Seguridad**
  - [ ] Login con credenciales incorrectas muestra error amigable
  - [ ] Acceso directo a /home sin login redirige a /login
  - [ ] No se exponen errores técnicos

- [ ] **Errores**
  - [ ] Accedo a URL no existente (/noexiste)
  - [ ] Veo página de error amigable

---

## 🎬 VIDEO RESUMEN DE PRUEBA

**Flujo completo (3 minutos):**

```
1. npm run dev                                        (10 seg)
2. Abrir http://localhost:3000                       (5 seg)
3. Ver página de login                               (5 seg)
4. Ingreso admin / admin123                          (5 seg)
5. Click "Iniciar Sesión"                            (2 seg)
6. Veo Dashboard                                     (10 seg)
7. Exploro Dashboard (tarjetas, módulos)             (30 seg)
8. Click en "Salir"                                  (3 seg)
9. Vuelvo a /login                                   (2 seg)
10. Intento login fallido                            (5 seg)
```

---

## 📊 ARQUITECTURA EJECUTÁNDOSE

**Lo que sucede detrás de escenas:**

```
USUARIO ACCEDE A http://localhost:3000
        ↓
[web/app.js] - Servidor Express escucha
        ↓
[web/routes/homeRoutes.js] - Verifica ruta "/"
        ↓
¿Usuario autenticado?
    NO  → [web/routes/authRoutes.js] - Redirige a /login
    SÍ  → [web/controllers/homeController.js] - Muestra /home
        ↓
[web/views/login.ejs] - Renderiza formulario
        ↓
USUARIO INGRESA CREDENCIALES
        ↓
[web/controllers/authController.js] - procesarLogin()
        ↓
[web/models/userModel.js] - obtenerPorNombreUsuario()
        ↓
[web/config/database.js] - Ejecuta consulta parametrizada
        ↓
¿Contraseña correcta? (bcrypt.compare)
    NO  → Muestra error amigable
    SÍ  → Crea sesión (req.session.usuario)
        ↓
USUARIO VE DASHBOARD
        ↓
[web/controllers/homeController.js] - mostrarHome()
        ↓
[web/views/home.ejs] - Renderiza dashboard
```

---

## 💾 ARCHIVOS QUE SE USAN DURANTE LA EJECUCIÓN

```
.env                          ← Lee variables (no crear, copiar de .env.example)
web/app.js                    ← Inicia servidor
web/config/envConfig.js       ← Lee .env
web/config/database.js        ← Conecta a BD
web/routes/authRoutes.js      ← GET /login, POST /login, GET /logout
web/routes/homeRoutes.js      ← GET /home, GET /
web/controllers/authController.js  ← Procesa login
web/controllers/homeController.js  ← Renderiza dashboard
web/models/userModel.js       ← Consulta usuarios en BD
web/views/layout.ejs          ← Plantilla base
web/views/login.ejs           ← Formulario login
web/views/home.ejs            ← Dashboard
web/public/css/style.css      ← Estilos
web/public/js/main.js         ← Scripts cliente
```

---

## 🎯 SIGUIENTE PASO

Una vez que pruebes todo correctamente:

1. Revisa `docs/entrega-2/AVANCE_WEB.md` para detalles técnicos
2. Lee `docs/entrega-2/BITACORA_TRABAJO.md` para ver todo lo que se realizó
3. Explora el código en `web/` para entender la arquitectura
4. Prepárate para integrar los módulos CRUD del Desarrollador 4

---

## 📞 HELP

Si algo no funciona:

1. **Verificar MySQL está corriendo**
2. **Verificar .env tiene valores correctos**
3. **Revisar logs en la consola**
4. **Leer GUIA_INSTALACION.md para solución de problemas**

---

**¡Listo para probar! 🚀**


[def]: https://nodejs.org/