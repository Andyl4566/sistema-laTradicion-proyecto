/**
 * SCRIPT SQL - Crear tabla de usuarios
 * Empresa de Tortillas, Nachos y Harina
 * Entrega 2
 * 
 * INSTRUCCIONES:
 * 1. Conectar a la base de datos BDTradicion
 * 2. Ejecutar este script completo
 * 3. Verificar que la tabla se creó correctamente
 * 
 * NOTA: Para generar el hash de bcrypt de una contraseña:
 *   En Node.js:
 *   const bcrypt = require('bcryptjs');
 *   const hash = await bcrypt.hash('admin123', 10);
 *   console.log(hash);
 */

-- ========== CREAR TABLA USUARIOS ==========
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(50) UNIQUE NOT NULL COMMENT 'Login del usuario',
  email VARCHAR(100) UNIQUE NOT NULL COMMENT 'Email del usuario',
  password_hash VARCHAR(255) NOT NULL COMMENT 'Contraseña hasheada con bcrypt',
  nombre_completo VARCHAR(100) NOT NULL COMMENT 'Nombre completo del usuario',
  activo TINYINT DEFAULT 1 COMMENT '1 = activo, 0 = inactivo',
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha de creación del registro',
  fecha_ultima_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  INDEX idx_nombre_usuario (nombre_usuario),
  INDEX idx_email (email),
  INDEX idx_activo (activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ========== INSERTAR USUARIO DE PRUEBA ==========
/**
 * Usuario: admin
 * Contraseña: admin123
 * Hash bcrypt: $2a$10$N9qo8ucowan11ie3yppK2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW
 * 
 * Para generar tu propio hash:
 * Node.js:
 *   const bcrypt = require('bcryptjs');
 *   bcrypt.hash('admin123', 10).then(hash => console.log(hash));
 * 
 * PHP:
 *   echo password_hash('admin123', PASSWORD_BCRYPT);
 */

INSERT INTO usuarios (nombre_usuario, email, password_hash, nombre_completo, activo)
VALUES (
  'admin',
  'admin@empresa.com',
  '$2a$10$N9qo8ucowan11ie3yppK2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW',
  'Administrador del Sistema',
  1
);

-- ========== VERIFICAR DATOS ==========
-- Ejecutar después de insertar para verificar
-- SELECT * FROM usuarios;

-- ========== CONSULTAS ÚTILES ==========

-- Obtener usuario por nombre (esta es la consulta que usa el login)
-- SELECT * FROM usuarios WHERE nombre_usuario = ? AND activo = 1;

-- Obtener usuario por email
-- SELECT * FROM usuarios WHERE email = ? AND activo = 1;

-- Obtener todos los usuarios activos
-- SELECT * FROM usuarios WHERE activo = 1 ORDER BY fecha_creacion DESC;

-- Desactivar usuario (soft delete)
-- UPDATE usuarios SET activo = 0 WHERE id_usuario = ?;

-- ========== EJEMPLO: INSERTAR MÁS USUARIOS ==========
/**
 * Si deseas agregar más usuarios de prueba:
 * 
 * INSERT INTO usuarios (nombre_usuario, email, password_hash, nombre_completo, activo)
 * VALUES (
 *   'vendedor1',
 *   'vendedor1@empresa.com',
 *   '$2a$10$...',  -- Hash de contraseña con bcrypt
 *   'Juan Pérez Vendedor',
 *   1
 * );
 * 
 * INSERT INTO usuarios (nombre_usuario, email, password_hash, nombre_completo, activo)
 * VALUES (
 *   'gestor1',
 *   'gestor1@empresa.com',
 *   '$2a$10$...',
 *   'María García Gestora',
 *   1
 * );
 */

-- ========== INFORMACIÓN COMPLEMENTARIA ==========
/**
 * ESTRUCTURA DE LA TABLA:
 * 
 * ┌─────────────────────────┬────────────────┬─────────────────────────────────┐
 * │ Campo                   │ Tipo           │ Descripción                     │
 * ├─────────────────────────┼────────────────┼─────────────────────────────────┤
 * │ id_usuario              │ INT PK AUTO    │ Identificador único             │
 * │ nombre_usuario          │ VARCHAR(50)    │ Login (UNIQUE)                  │
 * │ email                   │ VARCHAR(100)   │ Email (UNIQUE)                  │
 * │ password_hash           │ VARCHAR(255)   │ Contraseña hasheada (bcrypt)    │
 * │ nombre_completo         │ VARCHAR(100)   │ Nombre para mostrar             │
 * │ activo                  │ TINYINT        │ 1=activo, 0=inactivo            │
 * │ fecha_creacion          │ DATETIME       │ Timestamp de creación           │
 * │ fecha_ultima_actualizacion│ DATETIME      │ Timestamp de actualización      │
 * └─────────────────────────┴────────────────┴─────────────────────────────────┘
 * 
 * CONSIDERACIONES DE SEGURIDAD:
 * - Las contraseñas NUNCA se guardan en texto plano
 * - Se usan hashes bcrypt (sal incluida)
 * - En el código, se comparan con bcrypt.compare()
 * - El campo password_hash tiene 255 caracteres para soportar futuras mejoras
 * 
 * ÍNDICES:
 * - idx_nombre_usuario: Mejora búsqueda por login
 * - idx_email: Mejora búsqueda por email
 * - idx_activo: Filtra usuarios activos rápidamente
 * 
 * COLLATION:
 * - utf8mb4_unicode_ci: Soporta caracteres especiales (acentos, ñ, etc.)
 * - Útil para nombres en español
 */
