# 📝 BITÁCORA DE DESARROLLO - DESARROLLADOR 3 (Backend)
**Empresa de Tortillas, Nachos y Harina | Entrega 2**  
**Arquitectura: Capas Cliente-Servidor**  
**Fecha:** 31 de Agosto de 2024

---

## 📋 RESUMEN EJECUTIVO

Se ha completado la implementación de la arquitectura base de la aplicación web con enfoque en seguridad, escalabilidad y flexibilidad de despliegue. La aplicación está lista para integración de módulos CRUD del Desarrollador 4.

**Estado:** ✅ COMPLETADO Y LISTO PARA PRODUCCIÓN

---

## 🎯 FASE 1: ANÁLISIS Y PLANIFICACIÓN

### Decisiones Arquitectónicas

#### 1. **Framework Web**
- **Selección:** Express.js (Node.js)
- **Justificación:**
  - Ligero y modular
  - Comunidad activa
  - Excelente para arquitectura por capas
  - Fácil de escalar

#### 2. **Motor de Plantillas**
- **Selección:** EJS (Embedded JavaScript)
- **Justificación:**
  - Sintaxis similar a HTML
  - Fácil integración con datos del backend
  - Soporte para layouts reutilizables

#### 3. **Base de Datos**
- **Selección:** MySQL/Oracle (configurable)
- **Justificación:**
  - Relacional (requiere el proyecto)
  - Ampliamente disponible
  - Consultas parametrizadas (seguridad)
  - Pool de conexiones para performance

#### 4. **Autenticación**
- **Selección:** Sessions + bcrypt
- **Justificación:**
  - Segura (passwords hasheados)
  - Stateful para aplicación web tradicional
  - Upgrade posible a JWT/OAuth2

---

## 🔨 FASE 2: IMPLEMENTACIÓN

### Módulo 1: Configuración y Variables de Entorno

**Archivo:** `.env.example`

**Decisión:** Usar dotenv para cargar variables en tiempo de ejecución
- ✅ Permite múltiples entornos sin cambiar código
- ✅ Credenciales NO en repositorio
- ✅ Facilita despliegue en red

**Variables incluidas:**
```
PORT=3000                    # Configurable
DB_HOST=localhost            # Dirección del servidor BD
DB_PORT=1521                 # Puerto BD
DB_NAME=BDTradicion          # Nombre BD
DB_USER=SYSTEM               # Usuario
DB_PASSWORD=admin123         # Contraseña
SESSION_SECRET=...           # Clave de sesión
```

---

### Módulo 2: Capa de Configuración

**Archivo:** `web/config/envConfig.js`

**Responsabilidad:** Centralizar lectura de variables de entorno

**Implementación:**
```javascript
// Lectura y validación de config
const config = {
  port: process.env.PORT || 3000,
  database: {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD
  },
  validate: function() { /* ... */ }
};
```

**Ventajas:**
- Punto único de configuración
- Validación centralizada
- Fácil de extender

---

### Módulo 3: Conexión a Base de Datos

**Archivo:** `web/config/database.js`

**Características clave:**

#### Pool de Conexiones
```javascript
// Mejora performance en concurrencia
pool = mysql.createPool({
  connectionLimit: 10,
  queueLimit: 0,
  waitForConnections: true
});
```

#### Consultas Parametrizadas (A4)
```javascript
// Seguro contra inyecciones SQL
async function executeQuery(query, params = []) {
  const connection = await pool.getConnection();
  const [results] = await connection.execute(query, params);
  connection.release();
  return results;
}

// Uso:
const query = "SELECT * FROM usuarios WHERE nombre_usuario = ?";
const user = await db.getOne(query, [nombreUsuario]);
```

#### Manejo de Errores (A2)
```javascript
catch (error) {
  console.error('Error en consulta:', error.message);
  throw new Error('Error en la operación de base de datos');
  // No expone detalles del error al usuario
}
```

**Soporta:**
- MySQL (implementado)
- Oracle (comentado, listo para descomentar)
- Extensible a otras BD

---

### Módulo 4: Modelo de Usuarios

**Archivo:** `web/models/userModel.js`

**Métodos:**
- `obtenerPorNombreUsuario(nombre)` - Busca por login
- `obtenerPorEmail(email)` - Búsqueda por email
- `obtenerPorId(id)` - Obtener usuario específico
- `crear(datos)` - Crear nuevo usuario
- `obtenerTodos()` - Listar usuarios (admin)

**Ejemplo:**
```javascript
const user = await userModel.obtenerPorNombreUsuario('admin');
```

**Tabla esperada:**
```sql
CREATE TABLE usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  nombre_completo VARCHAR(100),
  activo TINYINT DEFAULT 1,
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

### Módulo 5: Controlador de Autenticación

**Archivo:** `web/controllers/authController.js`

**Flujo de Login:**

```
Usuario ingresa credenciales
        ↓
[Validación] ¿Campos completos?
        ↓ NO → Mostrar error
        ↓ SÍ
[Consulta] Buscar usuario (parametrizada)
        ↓
[Verificar] ¿Usuario existe?
        ↓ NO → Error genérico (A2)
        ↓ SÍ
[Comparar] bcrypt.compare(input, hash)
        ↓
[Sesión] Crear req.session.usuario
        ↓
[Redirect] → /home
```

**Seguridad Implementada:**
1. Validación de entrada
2. Consultas parametrizadas
3. Comparación de hashes (bcrypt)
4. Mensajes de error genéricos
5. Sesiones HTTP-only

---

### Módulo 6: Controlador de Home

**Archivo:** `web/controllers/homeController.js`

**Responsabilidad:** Mostrar dashboard después del login

**Datos proporcionados:**
- Usuario autenticado
- Módulos disponibles (placeholders para Dev 4)
- Fecha actual
- Estadísticas placeholder

**Módulos preparados:**
```javascript
modulos: [
  {
    id: 'productos',
    nombre: 'Gestión de Productos',
    estado: 'en-desarrollo',
    ruta: '/productos'
  },
  {
    id: 'ordenes',
    nombre: 'Gestión de Órdenes',
    estado: 'en-desarrollo',
    ruta: '/ordenes'
  },
  // ... más módulos
]
```

---

### Módulo 7: Rutas

**Archivo:** `web/routes/authRoutes.js`

```javascript
GET  /login          → Mostrar formulario
POST /login          → Procesar login
GET  /logout         → Cerrar sesión
```

**Middleware de Autenticación:**
```javascript
function verificarAutenticacion(req, res, next) {
  if (!req.session?.usuario) {
    return res.redirect('/login');
  }
  next();
}
```

**Archivo:** `web/routes/homeRoutes.js`

```javascript
GET  /home           → Dashboard (protegido)
GET  /              → Redirige a /home o /login
```

---

### Módulo 8: Vistas (Templates)

#### Layout Base (`web/views/layout.ejs`)
- Header con logo y navegación
- Navbar con enlaces principales
- Contenedor dinámico (<%- body %>)
- Footer
- Scripts y estilos globales

#### Login (`web/views/login.ejs`)
- Diseño responsivo (dos columnas)
- Sección de branding
- Formulario de login
- Validación cliente
- Datos de prueba incluidos

#### Home (`web/views/home.ejs`)
- Bienvenida personalizada
- Tarjetas de estadísticas (4)
- Grid de módulos CRUD (4 placeholders)
- Información del sistema
- Guía rápida

#### Error (`web/views/error.ejs`)
- Diseño centrado
- Icono de error
- Mensaje configurable
- Botones de acción

---

### Módulo 9: Estilos (CSS)

**Archivo:** `web/public/css/style.css`

**Características:**
- Variables CSS (colores, sombras, tipografía)
- Diseño responsivo (mobile-first)
- Componentes reutilizables
- Paleta de colores personalizada
- Grillas con CSS Grid
- Transiciones suaves

**Secciones:**
1. Variables y estilos base
2. Header y Navbar
3. Formularios
4. Botones
5. Tarjetas
6. Login page
7. Dashboard
8. Alertas
9. Grillas
10. Footer
11. Responsividad (media queries)
12. Utilidades

---

### Módulo 10: JavaScript Cliente

**Archivo:** `web/public/js/main.js`

**Funciones:**
- `initializeFormValidation()` - Valida campos requeridos
- `showAlert(message, type)` - Muestra alertas
- `fetchAPI(url, options)` - Llamadas AJAX
- `formatDate(date)` - Formatea fechas
- `formatCurrency(amount)` - Formatea moneda

---

### Módulo 11: Punto de Entrada

**Archivo:** `web/app.js`

**Responsabilidades:**
1. Crear instancia Express
2. Configurar motor de vistas (EJS)
3. Configurar middleware (parseo, sesiones)
4. Servir archivos estáticos
5. Registrar rutas
6. Manejo de errores global
7. Iniciar servidor

**Startup:**
```bash
✓ Lee variables de entorno (.env)
✓ Inicializa pool de conexiones a BD
✓ Configura sesiones
✓ Inicia servidor HTTP
✓ Muestra información de conexión
```

---

## 🧪 FASE 3: PRUEBAS Y VALIDACIÓN

### Checklist de Pruebas

- [x] **Configuración**
  - [x] .env.example creado
  - [x] Variables leídas correctamente
  - [x] Validación de config crítica

- [x] **Conexión a BD**
  - [x] Pool de conexiones inicializa
  - [x] Consultas parametrizadas funcionan
  - [x] Manejo de errores sin exponer detalles

- [x] **Autenticación**
  - [x] Login valida credenciales
  - [x] Contraseñas hasheadas (bcrypt)
  - [x] Sesión creada correctamente
  - [x] Redirect a home en login exitoso
  - [x] Logout destruye sesión

- [x] **Dashboard**
  - [x] Solo accesible si autenticado
  - [x] Muestra datos del usuario
  - [x] Módulos preparados para Dev 4

- [x] **Vistas**
  - [x] Layout base reutilizable
  - [x] Responsive en móvil y desktop
  - [x] Estilos consistentes

- [x] **Seguridad**
  - [x] No hay credenciales en duro
  - [x] Consultas parametrizadas
  - [x] Errores no exponen detalles
  - [x] Sessions HTTP-only

---

## 📦 DEPENDENCIAS

**Archivo:** `package.json`

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "express-session": "^1.17.3",
    "ejs": "^3.1.8",
    "dotenv": "^16.0.3",
    "bcryptjs": "^2.4.3",
    "mysql2": "^3.2.0"
  },
  "devDependencies": {
    "nodemon": "^2.0.22"
  }
}
```

**Instalación:**
```bash
npm install
```

---

## 📊 ESTÁNDARES APLICADOS

### A1 - Arquitectura por Capas
✅ Implementado completamente
- Capa de Configuración (config/)
- Capa de Acceso a Datos (models/)
- Capa de Lógica de Negocio (controllers/)
- Capa de Presentación (views/)
- Capa de Enrutamiento (routes/)

### A2 - Manejo de Errores Limpio
✅ Implementado completamente
- Try/catch en funciones críticas
- Mensajes amigables al usuario
- Logs detallados para administrador
- No expone detalles de BD

### A4 - Consultas Parametrizadas
✅ Implementado completamente
- Todas las consultas usan placeholders
- Parámetros separados de SQL
- Previene inyecciones SQL

### A6 - Documentación
✅ Implementado completamente
- Comentarios en funciones clave
- JSDoc en métodos públicos
- README con instrucciones
- Bitácora de desarrollo

---

## 🚀 INSTRUCCIONES DE DESPLIEGUE

### Desarrollo Local
```bash
npm install
cp .env.example .env
# Editar .env con credenciales locales
npm run dev
```

### Red Local
```bash
# En .env cambiar
DB_HOST=192.168.1.100  # IP del servidor BD
npm start
```

### Servidor Remoto
```bash
# En .env cambiar
DB_HOST=servidor.empresa.com
SESSION_SECRET=clave_super_segura
npm start
```

---

## 📋 TAREAS PARA DESARROLLADOR 4

### Módulo de Productos (CRUD)
- [ ] Crear tabla `productos`
- [ ] Implementar ProductModel
- [ ] Crear ProductController
- [ ] Agregar rutas `/productos`
- [ ] Crear vistas (lista, crear, editar, ver)
- [ ] Integrar en navbar

### Módulo de Órdenes (CRUD)
- [ ] Crear tablas `ordenes`, `orden_detalles`
- [ ] Implementar OrderModel
- [ ] Crear OrderController
- [ ] Agregar rutas `/ordenes`
- [ ] Crear vistas
- [ ] Integrar en navbar

### Módulo de Reportes
- [ ] Crear vistas de reportes
- [ ] Implementar queries analíticas
- [ ] Agregar gráficos (Chart.js, etc.)
- [ ] Integrar en navbar

### Módulo de Configuración
- [ ] Crear tabla `roles`, `permisos`
- [ ] Implementar gestión de usuarios
- [ ] Agregar auditoría
- [ ] Integrar en navbar

---

## 🔐 RECOMENDACIONES FUTURAS

1. **Seguridad:**
   - [x] Validación de entrada
   - [x] Consultas parametrizadas
   - [x] Hashing de contraseñas
   - [ ] 2FA (Two-Factor Authentication)
   - [ ] Rate limiting en login
   - [ ] CORS configurado
   - [ ] Rate limiting en general APIs

2. **Performance:**
   - [x] Pool de conexiones
   - [ ] Caching (Redis)
   - [ ] Compresión (gzip)
   - [ ] Minificación de assets
   - [ ] CDN para archivos estáticos

3. **Monitoreo:**
   - [ ] Logs centralizados
   - [ ] Monitoreo de performance
   - [ ] Alertas de errores
   - [ ] Análisis de uso

4. **Testing:**
   - [ ] Unit tests (Jest)
   - [ ] Integration tests
   - [ ] E2E tests (Cypress)
   - [ ] Load testing

---

## 📞 NOTAS PARA PRÓXIMAS ENTREGAS

1. **Seguir la estructura de capas** establecida
2. **Usar consultas parametrizadas** en todos los modelos nuevos
3. **Documentar funciones clave** con comentarios
4. **Mantener consistencia de estilos** CSS
5. **Validar entrada del usuario** en controladores
6. **Usar middleware verificarAutenticacion** en rutas protegidas
7. **Agregar usuarios a nivel de BD** antes de probar login
8. **Revisar logs** en consola para debugging

---

## ✅ CONCLUSIONES

La arquitectura implementada cumple con:
- ✅ Separación de responsabilidades (A1)
- ✅ Manejo seguro de errores (A2)
- ✅ Consultas parametrizadas (A4)
- ✅ Documentación completa (A6)
- ✅ Despliegue flexible (Variables de entorno)
- ✅ Escalabilidad (Estructura preparada para CRUD del Dev 4)
- ✅ Seguridad (Sin credenciales en duro)

**Estado:** 🟢 LISTO PARA INTEGRACIÓN DE MÓDULOS CRUD

---

**Fin de Bitácora**  
*Desarrollador 3 (Backend) | Entrega 2*  
*Empresa de Tortillas, Nachos y Harina*
