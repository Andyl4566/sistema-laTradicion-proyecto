# Configuración MySQL de la aplicación web

La aplicación de Entrega 2 utiliza MySQL y el esquema `bd_tradicion`.

Variables requeridas en `.env`:

```env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=bd_tradicion
DB_USER=root
DB_PASSWORD=TU_CONTRASENA_MYSQL
```

La conexión se implementa con `mysql2/promise` mediante un pool de conexiones. Las consultas de login, clientes y proveedores usan parámetros `?` para evitar concatenar datos ingresados por el usuario.
