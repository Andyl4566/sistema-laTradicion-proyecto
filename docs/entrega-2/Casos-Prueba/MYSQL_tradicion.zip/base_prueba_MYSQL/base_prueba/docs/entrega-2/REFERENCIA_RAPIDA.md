# 📋 REFERENCIA RÁPIDA
**Empresa de Tortillas, Nachos y Harina | Entrega 2**

---

## 🚀 Inicio en 3 Pasos

```bash
# 1. Instalar dependencias
npm install

# 2. Configurar .env
cp .env.example .env
# Editar DB_HOST, DB_USER, DB_PASSWORD

# 3. Iniciar servidor
npm run dev
```

**Acceder:** `http://localhost:3000`  
**Login:** `admin` / `admin123`

---

## 📁 Estructura de Archivos

```
proyecto/
├── web/
│   ├── app.js              ← PUNTO DE ENTRADA
│   ├── config/
│   │   ├── envConfig.js    ← Lee variables de entorno
│   │   └── database.js     ← Pool de conexiones a BD
│   ├── models/
│   │   └── userModel.js    ← Consultas parametrizadas
│   ├── controllers/
│   │   ├── authController.js
│   │   └── homeController.js
│   ├── routes/
│   │   ├── authRoutes.js   ← GET/POST /login, /logout
│   │   └── homeRoutes.js   ← GET /home
│   ├── views/
│   │   ├── layout.ejs      ← Plantilla base
│   │   ├── login.ejs
│   │   ├── home.ejs
│   │   └── error.ejs
│   └── public/
│       ├── css/style.css   ← Estilos
│       └── js/main.js      ← Scripts cliente
├── .env.example            ← Template de config
├── .env                    ← CREAR: cp .env.example .env
├── package.json
└── docs/
    └── entrega-2/
        ├── AVANCE_WEB.md
        ├── GUIA_INSTALACION.md
        ├── schema.sql
        └── bitacora-ia/BITACORA_DEV3.md
```

---

## ⚙️ Variables de Entorno

```env
PORT=3000                          # Puerto del servidor
DB_HOST=localhost                  # Host de BD (o IP)
DB_PORT=3306                       # Puerto BD (3306 MySQL, 1521 Oracle)
DB_NAME=BDTradicion                # Nombre BD
DB_USER=root                       # Usuario BD
DB_PASSWORD=admin123               # Contraseña BD
SESSION_SECRET=clave_secreta       # Clave de sesión
```

---

## 🔑 Rutas de la Aplicación

| Método | Ruta | Descripción | Auth | 
|--------|------|-------------|------|
| GET | `/` | Redirige a /home o /login | No |
| GET | `/login` | Mostrar formulario | No |
| POST | `/login` | Procesar login | No |
| GET | `/logout` | Cerrar sesión | **Sí** |
| GET | `/home` | Dashboard | **Sí** |
| GET | `/health` | Estado del servidor | No |

---

## 🔐 Seguridad Implementada

✅ **Consultas Parametrizadas (A4)**
```javascript
// ✓ SEGURO
const query = "SELECT * FROM usuarios WHERE nombre_usuario = ?";
db.getOne(query, [usuario]);

// ✗ INSEGURO (NO USAR)
const query = `SELECT * FROM usuarios WHERE nombre_usuario = '${usuario}'`;
```

✅ **Manejo de Errores Limpio (A2)**
```javascript
// No exponer detalles técnicos
res.render('login', {
  mensajeError: 'Usuario o contraseña incorrectos'
});
```

✅ **Hashing de Contraseñas**
```javascript
// Verificar con bcrypt
const valid = await bcrypt.compare(inputPassword, storedHash);
```

✅ **Sesiones Seguras**
```javascript
// HTTP-only cookies
cookie: { secure: true, httpOnly: true }
```

---

## 📊 Modelo de Datos

### Tabla: usuarios

```sql
CREATE TABLE usuarios (
  id_usuario INT PRIMARY KEY AUTO_INCREMENT,
  nombre_usuario VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  nombre_completo VARCHAR(100),
  activo TINYINT DEFAULT 1,
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

**Usuario de prueba:**
- Usuario: `admin`
- Contraseña: `admin123`
- Email: `admin@empresa.com`

---

## 🛠️ Comandos Útiles

```bash
# Instalación
npm install                  # Instalar dependencias
npm update                   # Actualizar dependencias

# Desarrollo
npm run dev                  # Con recarga automática (nodemon)
npm start                    # Sin recarga automática
Ctrl+C                       # Detener servidor

# Base de Datos
mysql -u root -p BDTradicion < docs/entrega-2/schema.sql
# Ejecutar script SQL

mysql -u root -p BDTradicion
# Conectar a BD interactivamente

# Otros
npm list                     # Ver dependencias instaladas
node --version               # Ver versión Node.js
npm --version                # Ver versión npm
```

---

## 🚀 Despliegue en Red

### Cambiar de localhost a servidor remoto

**En `.env`:**
```env
# ANTES
DB_HOST=localhost

# DESPUÉS
DB_HOST=192.168.1.100  # IP del servidor BD
```

**Requisitos:**
- Servidor BD accesible desde la red
- Puerto DB_PORT abierto
- Credenciales válidas para acceso remoto

```bash
# Reiniciar servidor
npm start
```

---

## 📝 Stack Tecnológico

| Componente | Tecnología | Versión |
|-----------|-----------|---------|
| Backend | Node.js | ≥14 |
| Framework | Express.js | ^4.18 |
| Vistas | EJS | ^3.1 |
| BD | MySQL/Oracle | - |
| Cliente BD | mysql2 | ^3.2 |
| Autenticación | bcryptjs | ^2.4 |
| Sesiones | express-session | ^1.17 |
| Env Config | dotenv | ^16 |
| Dev Tools | nodemon | ^2.0 |

---

## 🔍 Debugging

### Ver logs
```bash
# Logs en consola donde corre "npm start"
# Buscar líneas que empiezan con ✓ o ✗
```

### Probar conexión a BD
```bash
# En MySQL
mysql -u root -p -e "SELECT 1;"

# Desde Node.js
node
> const mysql = require('mysql2/promise');
> // verificar conexión
```

### Revisar variables de entorno
```bash
cat .env
# Verificar que DB_HOST, DB_USER, DB_PASSWORD son correctos
```

### Ver tablas de BD
```bash
mysql -u root -p BDTradicion -e "SHOW TABLES;"
mysql -u root -p BDTradicion -e "DESCRIBE usuarios;"
```

---

## 💾 Estructura de Capas

```
┌─────────────────────────────────────────┐
│       PRESENTACIÓN (views/)             │  EJS Templates
├─────────────────────────────────────────┤
│       ENRUTAMIENTO (routes/)            │  Express Routes
├─────────────────────────────────────────┤
│   LÓGICA NEGOCIO (controllers/)         │  Controllers
├─────────────────────────────────────────┤
│   ACCESO DATOS (models/)                │  Database Queries
├─────────────────────────────────────────┤
│   CONFIGURACIÓN (config/)               │  BD Pool, Env
└─────────────────────────────────────────┘
```

---

## 🎯 Próximos Módulos (Dev 4)

- [ ] Gestión de Productos (/productos)
- [ ] Gestión de Órdenes (/ordenes)
- [ ] Reportes (/reportes)
- [ ] Configuración (/configuracion)

**Patrón a seguir:**
1. Crear tabla en BD
2. Crear Model (web/models/...)
3. Crear Controller (web/controllers/...)
4. Crear Routes (web/routes/...)
5. Crear Views (web/views/...)

---

## 🐛 Errores Comunes

| Error | Causa | Solución |
|-------|-------|----------|
| `Cannot find module 'express'` | Dependencias no instaladas | `npm install` |
| `Error de conexión a BD` | Config incorrecta | Revisar `.env` |
| `Puerto 3000 en uso` | Otro proceso ocupa puerto | Cambiar PORT en `.env` |
| `Tabla no existe` | Script SQL no ejecutado | `mysql ... < schema.sql` |
| `Login falla` | Usuario no existe | Crear usuario en BD |

---

## 📞 Archivos de Referencia

- **README.md** - Descripción general
- **AVANCE_WEB.md** - Estado del proyecto
- **GUIA_INSTALACION.md** - Pasos de setup
- **BITACORA_DEV3.md** - Detalles técnicos
- **schema.sql** - Estructura de BD

---

## ✅ Checklist de Inicio

- [ ] Node.js ≥ v14 instalado
- [ ] npm instalado
- [ ] Base de datos MySQL/Oracle creada
- [ ] `npm install` ejecutado
- [ ] `.env` configurado con credenciales correctas
- [ ] Tabla `usuarios` creada en BD
- [ ] Usuario `admin` existe en BD
- [ ] `npm run dev` iniciado sin errores
- [ ] Login funciona en `http://localhost:3000`
- [ ] Dashboard visible después del login

---

**Versión:** 1.0.0 | **Estado:** ✅ Listo para usar | **Última actualización:** 31/08/2024
